# -*- encoding: utf-8 -*-

class FSEvent
  VERSION = '0.11.2'
end

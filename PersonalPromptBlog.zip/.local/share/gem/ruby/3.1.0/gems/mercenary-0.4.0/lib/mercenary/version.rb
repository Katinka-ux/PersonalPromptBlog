# frozen_string_literal: true

module Mercenary
  VERSION = "0.4.0"
end

#
# All the code from this file is now implemented in C.  This file remains
# to satisfy any leftover require 'ffi/callback' in user code
#

module FFI
  VERSION = '1.17.2'
end

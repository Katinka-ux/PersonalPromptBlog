module Concurrent
  VERSION = '1.3.5'
end
